package com.seavillage.ohgi.meteor

import com.github.noonmaru.psychics.*
import com.github.noonmaru.psychics.attribute.EsperAttribute
import com.github.noonmaru.psychics.attribute.EsperStatistic
import com.github.noonmaru.psychics.damage.Damage
import com.github.noonmaru.psychics.damage.DamageType
import com.github.noonmaru.psychics.util.TargetFilter
import com.github.noonmaru.tap.config.Config
import com.github.noonmaru.tap.config.Name
import com.github.noonmaru.tap.effect.playFirework
import com.github.noonmaru.tap.fake.FakeEntity
import com.github.noonmaru.tap.fake.Movement
import com.github.noonmaru.tap.fake.Trail
import com.github.noonmaru.tap.math.copy
import com.github.noonmaru.tap.math.normalizeAndLength
import com.github.noonmaru.tap.trail.trail
import org.bukkit.*
import org.bukkit.entity.ArmorStand
import org.bukkit.entity.LivingEntity
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.block.Action
import org.bukkit.event.player.PlayerInteractEvent
import org.bukkit.inventory.ItemStack
import org.bukkit.util.BoundingBox

@Name("meteor")
class MeteorConcept : AbilityConcept() {

    @Config
    var meteorInitSpeed = 1.0

    @Config
    val meteorAcceleration = 0.04

    @Config
    var meteorTicks = 100

    @Config
    var meteorExplosionRadius = 3.0

    @Config
    var meteorSize = 1.0

    @Config
    var meteorKnockback = 3.0

    init {
        displayName = "유성"
        type = AbilityType.ACTIVE
        cost = 100.0
        range = 64.0
        wand = ItemStack(Material.NETHER_STAR)
        supplyItems = listOf(ItemStack(Material.NETHER_STAR))
        damage = Damage(DamageType.BLAST, EsperStatistic.of(EsperAttribute.ATTACK_DAMAGE to 7.0)) // 데미지 설정
        description = listOf(
            "유성을 우클릭 시 현재 좌표에 유성을 추락시 킵니다.",
            "유성은 빙빙 돌며 떨어지다 블록에 부딪힐 시 폭발을 일으켜",
            "7 블록 내의 적에게 <damage>의 피해를 입힙니다."
        )
    }
}

class Meteor : Ability<MeteorConcept>(), Listener {
    private var meteor: Meteors? = null

    override fun onEnable() {
        psychic.run {
            registerEvents(this@Meteor)
        }
    }

    @EventHandler
    fun onPlayerInteract(event: PlayerInteractEvent) {
        event.item?.let { item ->
            val type = item.type

            if (type.equals(concept.wand)) {
                if (event.action == Action.LEFT_CLICK_AIR) {
                    meteor?.let { Meteorc ->
                        val projectile = MeteorProjectile(Meteorc)
                        psychic.launchProjectile(Meteorc.location, projectile)
                        projectile.velocity = Meteorc.location.direction.multiply(concept.meteorInitSpeed)
                        this.meteor = null
                    }
                }
            }
        }
    }

    inner class Meteors(
        internal val location: Location
    ) {
        private val entity: FakeEntity = psychic.spawnFakeEntity(location.clone(), ArmorStand::class.java).apply {
            updateMetadata<ArmorStand> {
                isVisible = false
            }
            updateEquipment {
                helmet = concept.wand
            }
        }

        fun updateLocation(newLoc: Location = location) {
            val x = newLoc.x
            val y = newLoc.y
            val z = newLoc.z

            location.apply {
                world = newLoc.world
                this.x = x
                this.y = y
                this.z = z
            }

            val loc = newLoc.clone()

            entity.moveTo(loc.apply {
                copy(newLoc)
            })
        }

        fun remove() {
            entity.remove()
        }
    }

    inner class MeteorProjectile(
        private val meteors: Meteors
    ) : PsychicProjectile(
        concept.meteorTicks, concept.range
    ) {
        override fun onMove(movement: Movement) {
            meteors.updateLocation(movement.to)
        }

        override fun onTrail(trail: Trail) {
            trail.velocity?.let { velocity ->
                val from = trail.from
                val world = from.world
                val length = velocity.normalizeAndLength()
                val filter = TargetFilter(esper.player)

                world.rayTrace(
                    from,
                    velocity,
                    length,
                    FluidCollisionMode.NEVER,
                    true,
                    concept.meteorSize,
                    filter
                )?.let { result ->
                    remove()

                    val hitPosition = result.hitPosition
                    val hitLocation = hitPosition.toLocation(world)

                    val firework =
                        FireworkEffect.builder().with(FireworkEffect.Type.BALL_LARGE).withColor(Color.RED).build()
                    world.playFirework(hitLocation, firework)

                    concept.damage?.let { damage ->
                        val radius = concept.meteorExplosionRadius
                        val box = BoundingBox.of(hitPosition, radius, radius, radius)

                        for (entity in world.getNearbyEntities(box, filter)) {
                            if (entity is LivingEntity) {
                                entity.psychicDamage(damage, hitLocation, concept.meteorKnockback)
                            }
                        }
                    }
                }

                val to = trail.to

                trail(from, to, 0.25) { w, x, y, z ->
                    w.spawnParticle(
                        Particle.FIREWORKS_SPARK,
                        x, y, z,
                        5,
                        0.1, 0.1, 0.1,
                        0.01, null, true
                    )
                }
            }
        }

        override fun onPostUpdate() {
            velocity = velocity.multiply(1.0 + concept.meteorAcceleration)
        }

        override fun onRemove() {
            meteors.remove()
        }
    }
}
